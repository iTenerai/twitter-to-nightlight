# twitter-to-nightlight
 Repost Twitter (X) posts directly to your Nightlight account with proper attribution!

## Still in development!
This extension is currently still in early development and doesn't work! Follow this repository to know when it's ready ^^
